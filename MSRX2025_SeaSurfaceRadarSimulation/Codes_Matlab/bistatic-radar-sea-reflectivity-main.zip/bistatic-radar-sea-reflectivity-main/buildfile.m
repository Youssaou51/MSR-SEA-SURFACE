function plan = buildfile
plan = buildplan();
plan.DefaultTasks = "test";

plan("check") = matlab.buildtool.tasks.CodeIssuesTask(".", IncludeSubfolders=true);

addpath(plan.RootFolder)
plan("test") = matlab.buildtool.tasks.TestTask("test", Strict=false);
end
